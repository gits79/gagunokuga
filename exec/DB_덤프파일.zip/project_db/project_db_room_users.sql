-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: ssafy-gagu.site    Database: project_db
-- ------------------------------------------------------
-- Server version	8.4.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `room_users`
--

DROP TABLE IF EXISTS `room_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room_users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `is_host` bit(1) NOT NULL,
  `room_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8i62x841algvy0v157lamg8g` (`room_id`),
  KEY `FKakm39gdnefr66uey9lf1ya26w` (`user_id`),
  CONSTRAINT `FK8i62x841algvy0v157lamg8g` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`),
  CONSTRAINT `FKakm39gdnefr66uey9lf1ya26w` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_users`
--

LOCK TABLES `room_users` WRITE;
/*!40000 ALTER TABLE `room_users` DISABLE KEYS */;
INSERT INTO `room_users` VALUES (10,_binary '',17,11),(11,_binary '',18,3),(13,_binary '',20,14),(14,_binary '',21,5),(15,_binary '',22,5),(16,_binary '',23,5),(17,_binary '',24,5),(18,_binary '',25,5),(19,_binary '',26,3),(23,_binary '',30,13),(26,_binary '',33,16),(32,_binary '',39,16),(33,_binary '',40,3),(34,_binary '',41,3),(35,_binary '',42,3),(36,_binary '',43,3),(37,_binary '',44,3),(39,_binary '',46,13),(42,_binary '\0',44,1),(43,_binary '\0',44,7),(47,_binary '',48,3),(48,_binary '\0',44,15),(49,_binary '',49,17),(51,_binary '',51,18),(54,_binary '',54,5),(55,_binary '\0',54,18),(56,_binary '',55,14),(58,_binary '',57,1),(60,_binary '',59,3),(61,_binary '',60,3),(63,_binary '\0',46,14),(64,_binary '\0',30,14),(65,_binary '',62,13),(66,_binary '',63,1),(67,_binary '\0',63,19),(68,_binary '\0',63,3),(70,_binary '',65,14),(72,_binary '',66,6),(78,_binary '',68,1),(79,_binary '\0',68,9),(80,_binary '',69,3),(88,_binary '',75,14),(89,_binary '',76,9),(90,_binary '\0',76,1),(92,_binary '',77,6),(101,_binary '',79,16),(102,_binary '',80,3),(104,_binary '\0',30,30),(105,_binary '\0',46,30),(110,_binary '\0',46,1),(111,_binary '\0',62,1),(112,_binary '\0',30,1),(113,_binary '',84,9),(114,_binary '',85,1),(115,_binary '\0',85,6),(116,_binary '\0',85,9),(119,_binary '\0',30,16);
/*!40000 ALTER TABLE `room_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21  9:52:37
