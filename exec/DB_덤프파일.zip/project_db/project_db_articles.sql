-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: ssafy-gagu.site    Database: project_db
-- ------------------------------------------------------
-- Server version	8.4.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `articles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `content` varchar(300) DEFAULT NULL,
  `title` varchar(100) NOT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKlc3sm3utetrj1sx4v9ahwopnr` (`user_id`),
  CONSTRAINT `FKlc3sm3utetrj1sx4v9ahwopnr` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` VALUES (2,'2025-02-13 08:44:05.333504','2025-02-13 08:44:05.420378','9평 투룸 신혼집 구경하고 가세요~','9평 투룸 신혼집',11),(3,'2025-02-13 08:44:46.931823','2025-02-13 08:44:47.025063','우드와 비비드 컬러로 만들어가는 24평 빌라 보고 가세요~','우드와 비비드 컬러로 만들어가는 24평 빌라',11),(5,'2025-02-13 08:49:06.046638','2025-02-13 08:49:06.129142','30평대 화이트 신혼집 인테리어 구경하고 가세요~','30평대 화이트 신혼집 인테리어',12),(6,'2025-02-13 08:49:49.756709','2025-02-13 08:49:49.861880','키치함 한방울 더해 세상 힙한 나만의 공간 구경하고 가세요~','키치함 한방울 더해 세상 힙한 나만의 공간',12),(7,'2025-02-13 08:51:24.935131','2025-02-13 08:51:25.060839','최적의 배치 보고가세요~','진짜 최적의 배치',12),(8,'2025-02-13 08:52:47.376820','2025-02-13 08:52:47.526986','따뜻하면서도 모던한 30평대 하우스 보고 가세요~','따뜻하면서도 모던한 30평대 하우스',11),(10,'2025-02-18 08:44:17.932864','2025-02-18 08:44:18.026056','asadad','faaf',1),(13,'2025-02-18 08:48:22.198505','2025-02-19 01:40:08.265120','204호','체리빌',13),(14,'2025-02-19 01:42:11.488245','2025-02-19 01:42:12.010839','목록','에셋',13);
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21  9:52:38
