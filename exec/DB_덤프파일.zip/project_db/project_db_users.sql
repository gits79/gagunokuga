-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: ssafy-gagu.site    Database: project_db
-- ------------------------------------------------------
-- Server version	8.4.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `is_admin` int NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `profile_image_url` varchar(255) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `provider_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK6dotkott2kjsp8vw4d0m25fb7` (`email`),
  UNIQUE KEY `UK2ty1xmrrgtn89xt7kyxx6ta7h` (`nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'2025-02-11 08:14:36.714515','2025-02-13 08:40:56.266682','g1767g@naver.com',0,'김지환',NULL,'http://k.kakaocdn.net/dn/BS5OA/btrTUDXKM6N/bZn5Hr7xQs9lBh13pPl2YK/img_640x640.jpg','kakao','3916142227'),(3,NULL,'2025-02-13 02:39:53.888669','test@t',0,'test','$2a$10$6/P.eBVJykfygykLxvBFJutUOSuhMaLl4K0R92laJzgRxfoJZkajy','https://api.dicebear.com/9.x/identicon/svg?seed=609',NULL,NULL),(4,'2025-02-11 23:58:59.856284','2025-02-11 23:58:59.856284','gjrudghks3117@gmail.com',0,'a607','$2a$10$k1/L2TXOxx2sUet0Z9HMu.u4sS/OPC6Uyurgs5sQT5AUQcjhZ7/Eq',NULL,NULL,NULL),(5,'2025-02-12 01:45:19.027263','2025-02-17 12:09:18.118536','daeunchang@naver.com',0,'다은',NULL,'http://k.kakaocdn.net/dn/sbXUb/btsMi5oeI7f/X9cWpaOZW6FkOwhDTM4fmK/img_640x640.jpg','kakao','3914403289'),(6,'2025-02-12 01:47:19.287449','2025-02-12 01:47:19.287449','yhkimx@dreamwiz.com',0,'김예훈',NULL,'http://k.kakaocdn.net/dn/wsQon/btsLLDyuMNN/ynsOLfIvzHhNCDTITtsgxk/img_640x640.jpg','kakao','3916393928'),(7,'2025-02-12 06:04:57.689594','2025-02-12 06:04:57.689594','ss@s.com',0,'ssafy','$2a$10$lBvfxpSSCKX6DgCiKumskeowUV0MwJ1X9nUfOwY5AWowT7oPfD9iy','https://api.dicebear.com/9.x/identicon/svg?seed=ssafy',NULL,NULL),(8,'2025-02-12 06:05:19.363234','2025-02-12 06:05:19.363234','ss1@s.com',0,'ssafy1','$2a$10$..eI2EGTac17HAmYRFlt7eByt0Hde7lGbt6ab3BfqhPLZZ38QATy2','https://api.dicebear.com/9.x/identicon/svg?seed=ssafy1',NULL,NULL),(9,'2025-02-12 06:43:02.987148','2025-02-20 11:53:19.775811','yhkimxo@gmail.com',0,'별이다섯개','$2a$10$dRWFqrg1GBgBrgmnlRFxMOM4UwcOmzhFQ4WWSqwLom4Mvs6KHPUAe','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/4155f2de-23a6-4bd6-974d-802bd710553f_ONZ74Q0.jpg',NULL,NULL),(10,'2025-02-13 01:48:24.252592','2025-02-13 01:48:24.252592','sangwoo108@gmail.com',0,'상우',NULL,'http://k.kakaocdn.net/dn/cyQyiS/btrX2pCgLTI/mR2fRZjgcm9fWBSBOSlkv0/img_640x640.jpg','kakao','3919073512'),(11,'2025-02-13 08:43:33.711457','2025-02-13 09:09:32.871900','wlghks1767@gmail.com',0,'집꾸미기','$2a$10$yg065qgrBPztzttGJd/tU.afBOBymtmCkFE/evBDpaaCnPxy.F0aq','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/ed46c76b-4f18-462d-be84-6a11b0204782_d1A_wD4kuLHmOOFqJdVlOXVt1TWA9NfNt_HA0CS0Y_N0zayUAX8olMuv7odG2FiDLDQZIRBqbPQwBSArXfEJlQ.webp',NULL,NULL),(12,'2025-02-13 08:48:00.101454','2025-02-13 08:48:17.324686','rhdxhd1597@gmail.com',0,'디귿','$2a$10$sww9X/WioKlYejCwSim2oO7ZwP.eWE29ChH7pjBnfg7s6j2Tqu0P.','https://api.dicebear.com/9.x/identicon/svg?seed=%EB%94%94%EA%B7%BF',NULL,NULL),(13,'2025-02-14 01:19:37.718537','2025-02-19 06:35:17.262106','qwedsaszxc@naver.com',0,'깊은방의유혹','$2a$10$LWRIcXnRu.veGNLMs0xNI.88rB/KfcSuut/oalwJgO6Ty4gYX4lWO','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/4ad1c7ea-fbfd-43d6-b3b5-42b94cfca89b_images.jpg',NULL,NULL),(14,'2025-02-15 06:43:15.989554','2025-02-15 06:43:15.989554','tgm@kakao.com',0,'송정호',NULL,'http://img1.kakaocdn.net/thumb/R640x640.q70/?fname=http://t1.kakaocdn.net/account_images/default_profile.jpeg','kakao','3916145564'),(15,'2025-02-15 14:05:24.167085','2025-02-15 14:05:24.167085','john.4748@daum.net',0,'이동현',NULL,'http://k.kakaocdn.net/dn/VknOk/btsd1h2VFXc/6Z74kLTZcXcy4ViKzVBJck/img_640x640.jpg','kakao','3922868973'),(16,'2025-02-18 10:17:39.801965','2025-02-18 10:17:39.801965','yoonji0624@naver.com',0,'심바맘','$2a$10$i14CtIHjCIdt2hKb2x2.h.WJ94DLpFgMMjsgvhEO0yexCB9nRqZSm','https://api.dicebear.com/9.x/identicon/svg?seed=%EC%8B%AC%EB%B0%94%EB%A7%98',NULL,NULL),(17,'2025-02-19 12:05:31.138694','2025-02-19 12:05:31.138694','yoonji0624@nate.com',0,'김윤지',NULL,'http://k.kakaocdn.net/dn/d0PeEr/btsH9XF9afb/01tbgbIwtyKFAJhzs78H2k/img_640x640.jpg','kakao','3916631948'),(18,'2025-02-20 00:28:30.734577','2025-02-20 00:28:30.734577','dshewaspretty@kakao.com',0,'이혜나',NULL,'http://k.kakaocdn.net/dn/bKa9Dw/btsLJeYZzX7/lCkkU39OkkYFbAEHXgNKPK/img_640x640.jpg','kakao','3929019174'),(19,'2025-02-20 06:16:18.686418','2025-02-20 06:16:18.686418','sobeast_1016@nate.com',0,'김예진',NULL,'http://k.kakaocdn.net/dn/KYztd/btrGEKa5v1o/oMeWNsO5kEaa04zHm7le90/img_640x640.jpg','kakao','3929506492'),(20,NULL,NULL,'A601@ssafy.com',0,'A601','$2a$10$6/P.eBVJykfygykLxvBFJutUOSuhMaLl4K0R92laJzgRxfoJZkajy','https://api.dicebear.com/9.x/identicon/svg?seed=601',NULL,NULL),(21,NULL,NULL,'A602@ssafy.com',0,'A602','$2a$10$6/P.eBVJykfygykLxvBFJutUOSuhMaLl4K0R92laJzgRxfoJZkajy','https://api.dicebear.com/9.x/identicon/svg?seed=602',NULL,NULL),(22,NULL,NULL,'A603@ssafy.com',0,'A603','$2a$10$6/P.eBVJykfygykLxvBFJutUOSuhMaLl4K0R92laJzgRxfoJZkajy','https://api.dicebear.com/9.x/identicon/svg?seed=603',NULL,NULL),(23,NULL,NULL,'A604@ssafy.com',0,'A604','$2a$10$6/P.eBVJykfygykLxvBFJutUOSuhMaLl4K0R92laJzgRxfoJZkajy','https://api.dicebear.com/9.x/identicon/svg?seed=604',NULL,NULL),(24,NULL,NULL,'A605@ssafy.com',0,'A605','$2a$10$6/P.eBVJykfygykLxvBFJutUOSuhMaLl4K0R92laJzgRxfoJZkajy','https://api.dicebear.com/9.x/identicon/svg?seed=605',NULL,NULL),(25,NULL,NULL,'A606@ssafy.com',0,'A606','$2a$10$6/P.eBVJykfygykLxvBFJutUOSuhMaLl4K0R92laJzgRxfoJZkajy','https://api.dicebear.com/9.x/identicon/svg?seed=605',NULL,NULL),(26,NULL,NULL,'A608@ssafy.com',0,'A608','$2a$10$6/P.eBVJykfygykLxvBFJutUOSuhMaLl4K0R92laJzgRxfoJZkajy','https://api.dicebear.com/9.x/identicon/svg?seed=608',NULL,NULL),(29,NULL,NULL,'A609@ssafy.com',0,'A609','$2a$10$6/P.eBVJykfygykLxvBFJutUOSuhMaLl4K0R92laJzgRxfoJZkajy','https://api.dicebear.com/9.x/identicon/svg?seed=609',NULL,NULL),(30,'2025-02-21 00:01:43.268426','2025-02-21 00:05:18.248186','qwedsaszxc@gmail.com',0,'나일론머스크','$2a$10$ac1KZf2kUGZ0tP6m7Skdn.Kzzqly/PJcerJRFli.pjLjA3bKG3QO6','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/3367cfc7-d8d9-40a0-bed0-e82f222048f5_images.jpg',NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21  9:52:39
