-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: ssafy-gagu.site    Database: project_db
-- ------------------------------------------------------
-- Server version	8.4.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rooms`
--

DROP TABLE IF EXISTS `rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rooms` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `room_name` varchar(255) NOT NULL,
  `thumbnail_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rooms`
--

LOCK TABLES `rooms` WRITE;
/*!40000 ALTER TABLE `rooms` DISABLE KEYS */;
INSERT INTO `rooms` VALUES (2,'2025-02-11 13:31:45.325781','2025-02-11 13:31:45.325781','방을 생성 후에 도면을 만드시고 저장 버튼을 눌러주세요',NULL),(4,'2025-02-12 00:12:41.387040','2025-02-12 00:12:41.387040','이집맛도리네',NULL),(6,'2025-02-12 01:53:17.552812','2025-02-12 01:53:17.552812','메롱',NULL),(7,'2025-02-12 02:05:51.900564','2025-02-12 02:05:51.900564','사피',NULL),(9,'2025-02-12 05:54:09.376516','2025-02-12 05:54:09.376516','sadasdasd',NULL),(10,'2025-02-12 05:54:30.041170','2025-02-12 05:54:30.041170','qweqweqweqw',NULL),(11,'2025-02-12 05:54:34.435408','2025-02-12 05:54:34.435408','qweqweqwewq',NULL),(12,'2025-02-12 05:56:24.433104','2025-02-12 05:56:24.433104','몽총이~~~',NULL),(13,'2025-02-12 05:56:33.335476','2025-02-12 05:56:33.335476','에디터에서 저장을 눌러주세요',NULL),(14,'2025-02-12 06:01:39.119370','2025-02-12 06:01:39.119370','sdfsdf',NULL),(15,'2025-02-12 06:49:57.258008','2025-02-12 06:49:57.258008','하이ㅋㅋ',NULL),(17,'2025-02-13 14:52:12.322205','2025-02-13 14:52:12.322205','dasdasdasdsa',NULL),(18,'2025-02-13 23:58:44.274450','2025-02-19 16:54:11.279869','ㅎㅎ','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/4013e647-b7f4-421f-835f-023722bacf3a_comb_img.png'),(20,'2025-02-15 06:43:22.412317','2025-02-15 06:43:22.412317','1231',NULL),(21,'2025-02-15 07:38:32.302823','2025-02-15 07:38:32.302823','d',NULL),(22,'2025-02-15 07:38:37.271906','2025-02-15 07:38:37.271906','d',NULL),(23,'2025-02-15 07:38:39.274083','2025-02-21 00:49:38.728786','d','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/4ee7a6bd-6106-499f-893b-3b738e9691bc_comb_img.png'),(24,'2025-02-15 07:38:42.528177','2025-02-15 07:38:42.528177','d',NULL),(25,'2025-02-15 07:38:44.639446','2025-02-15 07:38:44.639446','d',NULL),(26,'2025-02-15 12:14:53.304314','2025-02-19 10:28:09.980021','adf','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/157c54f9-6986-4140-ada9-b8f8597083e1_comb_img.png'),(30,'2025-02-18 07:51:09.336246','2025-02-21 00:51:59.750303','체리빌 204호','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/b3f478fb-bc7e-4e30-be51-753035c3a4d7_comb_img.png'),(33,'2025-02-18 10:23:44.928312','2025-02-18 10:23:44.928312','아타라시 하우스',NULL),(39,'2025-02-18 11:49:31.800323','2025-02-18 11:49:31.800323','ㅇㄹㅇㄹ',NULL),(40,'2025-02-18 11:58:02.242803','2025-02-20 05:31:35.053477','dfgdfgdgdf','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/d162ee14-2ebf-4900-bcde-4c377d835dfb_comb_img.png'),(41,'2025-02-18 23:37:29.230441','2025-02-21 00:02:38.048535','sc','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/d8f6cd3a-05f9-4402-850d-e39dcb694514_comb_img.png'),(42,'2025-02-18 23:37:31.730219','2025-02-20 09:25:24.438473','cxcx','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/08399575-7eed-4aee-9626-7acec0f3f7b5_comb_img.png'),(43,'2025-02-18 23:37:34.480429','2025-02-18 23:37:34.480429','xcx',NULL),(44,'2025-02-18 23:37:37.590193','2025-02-19 06:29:18.990781','cxxcxc','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/be5c141e-4b5c-4cf1-8b76-8c6a454c0d02_comb_img.png'),(46,'2025-02-19 01:25:29.602599','2025-02-21 00:50:57.533828','Assets','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/052c6a63-208c-42cf-81bb-bd6d842f0afe_comb_img.png'),(48,'2025-02-19 06:58:13.967872','2025-02-20 04:09:26.418461','만듬','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/5aabb2fc-f93e-4d20-94c3-0cdb4ed622bd_comb_img.png'),(49,'2025-02-19 12:05:47.848947','2025-02-19 12:05:47.848947','asdfasdf',NULL),(51,'2025-02-20 00:28:42.317528','2025-02-20 00:28:42.317528','진실의방',NULL),(54,'2025-02-20 01:05:14.924604','2025-02-21 00:49:23.712847','우르롹끼','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/6af2421a-a905-4da5-99ad-466e602b95bf_comb_img.png'),(55,'2025-02-20 01:07:06.956201','2025-02-20 01:07:06.956201','1234',NULL),(57,'2025-02-20 01:17:10.521917','2025-02-20 01:17:10.521917','asd',NULL),(59,'2025-02-20 04:09:49.428335','2025-02-20 04:09:49.428335','가구에디터로이동하는지테스트',NULL),(60,'2025-02-20 05:26:06.234169','2025-02-21 00:20:48.047818','시연입니다','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/d6d96993-6b75-439d-8d37-64af1f3b57ba_comb_img.png'),(62,'2025-02-20 06:12:32.931094','2025-02-21 00:51:28.755225','Room14','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/f68a726c-3f60-4d12-900f-3e2bd04ec7bf_comb_img.png'),(63,'2025-02-20 06:13:54.592432','2025-02-20 06:13:54.592432','예진님 여기에요',NULL),(65,'2025-02-20 06:45:25.400683','2025-02-20 06:45:25.400683','test',NULL),(66,'2025-02-20 07:20:28.618592','2025-02-20 11:52:11.351003','ㅇㅀㅇㄹㄶ','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/c3c323ab-112f-4c8f-b0f0-0ebc99f8d35e_comb_img.png'),(68,'2025-02-20 09:24:46.374741','2025-02-20 09:25:54.490661','예훈이형','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/ab72ba7d-9150-4f77-b198-e17038654691_comb_img.png'),(69,'2025-02-20 09:25:27.355992','2025-02-20 09:25:27.355992','dsd',NULL),(75,'2025-02-20 10:58:21.463874','2025-02-20 13:46:38.610063','abc','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/9c1b8e98-0b17-4ff4-bac5-022d861e0580_comb_img.png'),(76,'2025-02-20 11:38:40.615160','2025-02-20 11:38:40.615160','홀',NULL),(77,'2025-02-20 11:52:21.345018','2025-02-20 11:52:39.713345','ㅁㄴㅇㄻㅎㅁㄶ','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/453b3302-7945-47d8-b9df-b6a138a1500f_comb_img.png'),(79,'2025-02-20 23:52:55.407103','2025-02-20 23:52:55.407103','ㅎㅇㅎㅇ',NULL),(80,'2025-02-21 00:01:44.405889','2025-02-21 00:01:44.405889','aaa',NULL),(84,'2025-02-21 00:28:54.452118','2025-02-21 00:30:25.523326','asfag','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/f8a848f9-5f4c-4e10-b7a6-2b0d1a387641_comb_img.png'),(85,'2025-02-21 00:30:11.477169','2025-02-21 00:31:45.152791','asdasd','https://gagunokuga-uploaded-images.s3.ap-northeast-2.amazonaws.com/6930e4b5-f1ba-494a-a5d4-0a1ef66e69b8_comb_img.png');
/*!40000 ALTER TABLE `rooms` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21  9:52:37
